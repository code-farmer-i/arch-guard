import type { Preset, RoleDescriptor } from '../engine/types.js';
export interface CanonicalOptions {
    /** 源码根，默认 src */
    src?: string;
    /** 装配层：main / App / router / layouts */
    app?: string;
    /** 业务域根：每个子目录是一个域 */
    modules?: string;
    /** 跨域共享层 */
    shared?: string;
}
/**
 * 范式约定的角色表（见 PARADIGM.md「目录契约」）。
 * 判据只用「路径」，因此判定等级是 L1；每个文件必须**恰好命中一个角色**。
 * 层号用于依赖方向（`shared` 内部是线性层序，只许向下）。
 */
export declare function roleTable(options?: CanonicalOptions): RoleDescriptor[];
/** 范式 canonical 预设：目录契约 + 命名 + 阈值 + 层序 */
export declare function canonical(options?: CanonicalOptions): Preset;
