import type { UiKitAdapter } from '../../engine/types.js';
/**
 * antd 适配器：**唯一允许出现库名的地方**（引擎与通用预设里都不许出现）。
 * 换库 = 抄一份这个文件改字段；不用组件库 = 用 ui-kits/none。
 */
export declare function antdKit(): UiKitAdapter;
