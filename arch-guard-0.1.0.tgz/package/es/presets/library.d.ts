import type { Preset, RoleDescriptor } from '../engine/types.js';
export interface LibraryOptions {
    src?: string;
}
/**
 * 库 / CLI 工具范式（对比 `canonical()` 的应用范式）。
 *
 * 为什么需要它：应用的目录契约（装配 / 业务域 / 共享）对库不成立 ——
 * 库没有业务域、没有路由分片、也没有别名（内部相对导入是 Node 生态的常规写法）。
 * 强行用应用规则去量库，只会得到一堆与设计无关的报错。
 *
 * 于是「工程类型」也是一层可替换面：角色表 + 规则集一起换，引擎不动。
 */
export declare function libraryRoleTable(options?: LibraryOptions): RoleDescriptor[];
/**
 * 库范式预设：库的角色表 + 只启用与库相关的规则。
 * `S10`（禁相对越级 / 必须走别名）是应用专属规则 —— 库没有别名约定，关掉。
 */
export declare function library(options?: LibraryOptions): Preset;
