import { Command } from 'commander';
/** 输出全部经 output.ts 唯一出口（cli 自身不直接写 stdout） */
export declare function createProgram(): Command;
export declare function run(argv: string[]): Promise<number>;
