/**
 * 能力表 + 手工轮子指纹（纯数据）。
 *
 * 设计要点（见 docs/DESIGN.md §16）：
 * - 「该不该用成熟库」本身是 L5 判断；这里只钉**可判定的后果**：
 *   能力 → 首选库；以及「手工实现」的语法/命名指纹。
 * - 两档证据：`syntax` 单证据即报（形态无歧义）；`softSyntax` 必须与 `apiNames` 叠加才报（防误伤）。
 * - `allowOwn` 为 true 的能力只提示不报错 —— 有些小工具自研是合理的。
 * - 引擎与规则里不出现任何具体库名：库名只在本表与适配器里。
 */
export interface WheelFingerprint {
    /** 能力标识（选型表里的键） */
    capability: string;
    /** 登记的首选方案（包名或平台内置） */
    preferred: string[];
    /** 是否平台内置（无需依赖） */
    platform?: boolean;
    /** 强指纹：单证据即报（可缺省，表示该能力只能靠弱指纹 + 命名指纹判定） */
    syntax?: string[];
    /** 弱指纹：需与命名指纹叠加 */
    softSyntax?: string[];
    /** 该能力的常见公开 API 名（命名指纹：自研模块导出名重合 ≥2 即疑似） */
    apiNames?: string[];
    /** 报错时给的推荐写法 */
    hint: string;
    /** 允许项目内自研（只提示，不报错） */
    allowOwn?: boolean;
    note?: string;
}
export declare const wheelFingerprints: WheelFingerprint[];
export declare function capabilityOf(name: string): WheelFingerprint | undefined;
