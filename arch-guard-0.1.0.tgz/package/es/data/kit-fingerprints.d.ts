/**
 * 已知组件库指纹（纯数据）。
 * 用途：命中指纹但不在本项目适配表内 → 「框架残留」；换库时的迁移验收条件（见 docs/DESIGN.md §7.1）。
 * 这里只放数据，不含任何判定逻辑。
 */
export interface KitFingerprint {
    id: string;
    packages: string[];
    selectorPrefixes: string[];
    varPrefixes: string[];
}
export declare const kitFingerprints: KitFingerprint[];
export declare function fingerprintsOf(adapterPackages: string[]): KitFingerprint[];
