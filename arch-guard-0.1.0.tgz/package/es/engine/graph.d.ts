import type { Config, Facts } from './types.js';
export interface Graph {
    edges: Map<string, Set<string>>;
    importers: Map<string, Set<string>>;
    externals: Map<string, Set<string>>;
    unresolved: Map<string, string[]>;
    reachable: Set<string>;
    orphaned: string[];
    cycles: string[][];
}
/** 别名与相对路径解析；解析不到的项目内路径返回 null（第三方包单独记录） */
export declare function resolveSpecifier(spec: string, fromRel: string, config: Config, fileSet: Set<string>): string | null;
export interface BuildGraphInput {
    config: Config;
    files: string[];
    facts: Map<string, Facts>;
    /** CSS 文件原文（用于 @import / composes 的引用图） */
    cssTexts: Map<string, string>;
    entries?: string[];
}
export declare function buildGraph(input: BuildGraphInput): Graph;
