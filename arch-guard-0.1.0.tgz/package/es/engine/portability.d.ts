import type { Finding } from './types.js';
export interface PortabilityResult {
    findings: Finding[];
    checked: number;
}
export declare function checkPortability(packageRoot: string): PortabilityResult;
