import type { Config, FileRecord } from './types.js';
export declare const CSS_EXTENSIONS: string[];
export interface ScanResult {
    files: string[];
    records: FileRecord[];
    missing: string[];
    ambiguous: {
        rel: string;
        roles: string[];
    }[];
    ignored: string[];
    exempted: {
        rel: string;
        reason: string;
    }[];
}
/**
 * 扫出「文件 + 角色」。
 * 每个文件必须**恰好命中一个角色**（0 个 = 无处安放；≥1 个 = 歧义）—— 结构自检的基础。
 */
export declare function scanProject(config: Config): ScanResult;
