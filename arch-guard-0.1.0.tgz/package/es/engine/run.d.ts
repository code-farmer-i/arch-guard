import type { Config, Domain, Finding, Level, Rule, Severity } from './types.js';
export type ScopeMode = 'full' | 'changed' | 'staged' | `since:${string}`;
export interface RunOptions {
    cwd: string;
    configPath?: string;
    scope?: string;
    paths?: string[];
    domain?: Domain[];
    only?: string[];
    minLevel?: Level;
    severity?: Severity;
    updateBaseline?: boolean;
    reportOnly?: boolean;
    localOnly?: boolean;
    format?: 'pretty' | 'json' | 'github';
    rules: Rule[];
    quiet?: boolean;
}
export interface RunResult {
    exitCode: number;
    config: Config;
    all: Finding[];
    active: Finding[];
    scope: string;
    scopeFiles: string[];
    durationMs: number;
}
export declare function runGuard(options: RunOptions): Promise<RunResult>;
