import type { Config, Domain, Level, Rule } from './types.js';
/** 能力协商：未声明的能力对应规则**不注册**，并记入 skipped 供报告展示 */
export declare function hasCapability(config: Config, capability: string): boolean;
export interface RegistryFilters {
    only?: string[];
    domain?: Domain[];
    minLevel?: Level;
}
export interface RegistryResult {
    enabled: Rule[];
    skipped: {
        rule: string;
        reason: string;
    }[];
    unknownEnabled: string[];
    filters: RegistryFilters;
}
export declare function createRegistry(rules: Rule[], config: Config, filters?: RegistryFilters): RegistryResult;
