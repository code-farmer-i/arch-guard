/**
 * 依赖纪律的数据层：读取项目的依赖事实 + 把 config.params 里的策略解析成强类型。
 *
 * 三个字段的语义（见 PARADIGM.md §12）：
 * - allow        运行时依赖白名单（约束 package.json 的 dependencies）
 * - deny         明确禁用（命中即错，与 allow 无关）
 * - capabilities 能力 → 首选方案（约束**代码形态**：别手搓）
 */
export interface ProjectDeps {
    /** 项目根有没有 package.json；没有就整体跳过依赖类规则 */
    hasManifest: boolean;
    /** dependencies 里的包名 */
    runtime: string[];
    /** devDependencies 里的包名（工具链，不占运行时白名单） */
    dev: string[];
    /** peerDependencies 里的包名 */
    peer: string[];
    /** 三者并集 */
    declared: Set<string>;
    /** 源码里真实 import 的第三方包 */
    imported: Set<string>;
    /** import 了但没在任何 dependencies 段声明（幽灵依赖） */
    phantom: string[];
    /** 声明了但全项目零引用 */
    unused: string[];
}
export interface DepsPolicy {
    allow: string[];
    deny: string[];
    capabilities: Record<string, string>;
}
interface PackageJson {
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
    peerDependencies?: Record<string, string>;
}
export declare function readPackageJson(root: string): PackageJson | null;
/** 依赖事实：声明了什么、真实用了什么、两边对不上的（幽灵 / 死依赖） */
export declare function readProjectDeps(root: string, imported: Iterable<string>): ProjectDeps;
export declare function depsPolicyFrom(params: Record<string, unknown>): DepsPolicy;
/**
 * 策略自洽性检查：**配置自相矛盾必须报错，不能默默按某一侧生效**。
 * 例如：把某能力的首选库同时写进 deny。
 */
export declare function policyConflicts(policy: DepsPolicy, platformCapabilities?: Iterable<string>): string[];
export {};
