import type { Facts, FileRecord } from './types.js';
export declare const TS_EXTENSIONS: string[];
export interface FactInput {
    file: string;
    rel: string;
    role: string;
    text: string;
}
export declare function extractFacts(input: FactInput): Facts;
/** 供其它模块把 FileRecord 转成事实输入 */
export declare function factInputOf(record: FileRecord, text: string): FactInput;
