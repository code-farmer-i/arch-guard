import type { BaselineEntry } from './baseline.js';
import type { Config, Domain, Finding, Level, Rule, Severity } from './types.js';
export interface ReportInput {
    config: Config;
    ruleIndex: Map<string, Rule>;
    findings: Finding[];
    exemptedCount: number;
    unusedBaseline: BaselineEntry[];
    skipped: {
        rule: string;
        reason: string;
    }[];
    unknownEnabled: string[];
    notices: string[];
    scope: string;
    scopeFiles: number;
    globalFindings: number;
    durationMs: number;
    rulesEnabled: number;
    rulesTotal: number;
    /** 配置里 exempt 掉的文件数（豁免必须可见） */
    exemptedFiles: number;
}
export declare function severityOf(finding: Finding, ruleIndex: Map<string, Rule>): Severity;
export declare function summarize(findings: Finding[], ruleIndex: Map<string, Rule>): {
    errors: number;
    warnings: number;
};
export declare function renderReport(input: ReportInput): void;
export declare function renderSummary(input: ReportInput): void;
export interface JsonReport {
    ok: boolean;
    errors: number;
    warnings: number;
    scope: string;
    findings: (Finding & {
        domain?: Domain;
        level?: Level;
        severity: Severity;
    })[];
    skipped: {
        rule: string;
        reason: string;
    }[];
    exempted: number;
    durationMs: number;
}
export declare function toJsonReport(input: ReportInput): JsonReport;
