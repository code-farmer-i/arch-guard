import type { Preset } from './types.js';
export interface WalkOptions {
    skip?: Set<string>;
    extensions?: string[] | null;
}
/** 目录遍历：跳过忽略项，按扩展名收文件 */
export declare function walk(dir: string, { skip, extensions }?: WalkOptions): string[];
/** glob → RegExp：支持 ** / * / ?，仅用于项目内相对路径匹配（L1 判定） */
export declare function globToRegExp(glob: string): RegExp;
export declare function sha1(text: string): string;
/** 棘轮锚点：对格式化不敏感（去首尾空白、压缩内部空白） */
export declare function anchorOf(lineText: string | undefined): string;
export declare function readText(file: string): string;
export declare function readJson<T>(file: string): T;
export declare function exists(file: string): boolean;
export declare function relOf(root: string, file: string): string;
/** 预设合并：数组拼接，对象浅合并 */
export declare function mergePresets(presets: Preset[]): Preset;
export declare const color: {
    dim: (s: string) => string;
    red: (s: string) => string;
    yellow: (s: string) => string;
    green: (s: string) => string;
    cyan: (s: string) => string;
    bold: (s: string) => string;
};
