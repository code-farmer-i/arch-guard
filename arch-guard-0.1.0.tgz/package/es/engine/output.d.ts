/**
 * 唯一的输出出口：门禁自身也守「真相唯一」——
 * 全项目只在这里出现 console（eslint 对其它文件禁 console）。
 */
export declare function out(line?: string): void;
export declare function err(line?: string): void;
export declare function json(value: unknown): void;
