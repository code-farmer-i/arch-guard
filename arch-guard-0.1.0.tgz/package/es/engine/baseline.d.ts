import type { Finding } from './types.js';
/**
 * 棘轮：豁免锚点 = 规则 + 文件 + 稳定签名。
 * - 单行违规 → 规范化行文本哈希（那行一改，豁免立即失效）
 * - 文件级 / 符号级 → 由规则给出 anchor（锚点定义见 CONTEXT.md）
 */
export interface BaselineEntry {
    rule: string;
    file: string;
    anchor: string;
    anchorKind: 'line' | 'file' | 'symbol';
}
export interface BaselineFile {
    version: number;
    entries: BaselineEntry[];
}
export declare const EMPTY_BASELINE: BaselineFile;
export declare function loadBaseline(path: string): BaselineFile;
export declare function saveBaseline(path: string, entries: BaselineEntry[]): void;
export declare function anchorFor(finding: Finding, sourceOf: (rel: string) => string | undefined): BaselineEntry;
export interface BaselineSplit {
    active: Finding[];
    exempted: {
        finding: Finding;
        entry: BaselineEntry;
    }[];
    unused: BaselineEntry[];
}
export declare function applyBaseline(findings: Finding[], baseline: BaselineFile, sourceOf: (rel: string) => string | undefined): BaselineSplit;
export declare function entriesFromFindings(findings: Finding[], sourceOf: (rel: string) => string | undefined): BaselineEntry[];
