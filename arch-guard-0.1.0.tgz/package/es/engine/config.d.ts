import type { Config, Preset } from './types.js';
export interface RawProjectConfig {
    presets?: Preset[];
    /** 项目差异只写这里；与预设合并后即最终配置 */
    overrides?: Partial<Config>;
}
export interface LoadedConfig {
    config: Config;
    notices: string[];
    path: string;
}
/** 别名只从 tsconfig 读（单一出处，避免两处真相） */
export declare function aliasesFromTsconfig(root: string): {
    aliases: Record<string, string>;
    notice?: string;
};
export declare function loadConfig(options: {
    root: string;
    configPath?: string;
}): Promise<LoadedConfig>;
