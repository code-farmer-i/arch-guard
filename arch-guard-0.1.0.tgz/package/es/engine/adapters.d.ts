import type { Adapter } from './types.js';
export declare const FACETS: string[];
/** 能力根名 → 适配器面（capability 用 `uiKit.vendorSelectors` 这种路径表达） */
export declare const CAPABILITY_ROOTS: Record<string, string>;
export declare class AdapterError extends Error {
    constructor(message: string);
}
/** 校验并冻结一个适配器声明；未知字段直接报错（防拼写错导致静默失能） */
export declare function defineAdapter<T extends Adapter>(facet: string, spec: Record<string, unknown>): T;
/** 读取适配器的能力路径值：`uiKit.vendorSelectors` → adapter.vendorSelectors */
export declare function capabilityValue(adapter: unknown, path: string[]): unknown;
/** 能力是否真的可用：非空数组 / 非空字符串 / 显式 true */
export declare function isCapabilityPresent(value: unknown): boolean;
