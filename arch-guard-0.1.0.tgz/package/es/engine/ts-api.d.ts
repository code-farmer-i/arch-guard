/** 纯函数：返回问题描述；没问题返回 null（便于单测，不依赖真实 typescript） */
export declare function describeTypeScriptProblem(api: unknown): string | null;
export declare function assertTypeScriptApi(api: unknown): void;
