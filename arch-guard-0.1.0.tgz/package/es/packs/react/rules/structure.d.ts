import type { Rule } from '../../../engine/types.js';
/** S00 解析失败必须报错：fail-closed —— 语法错误会让该文件失去全部检查，绝不能静默通过 */
export declare const parseFailClosed: Rule;
/** S01 角色表互斥完备：每个文件必须恰好命中一个角色 */
export declare const roleTableComplete: Rule;
/** S02 目录深度 ≤3（相对源码根）：域内槽位下不许再嵌套 */
export declare const maxDepth: Rule;
/** S10 禁相对越级：跨目录一律走别名 */
export declare const noParentImport: Rule;
/** S11 禁 barrel：`export *` 会把真实依赖藏起来，使依赖图不可判定 */
export declare const noBarrel: Rule;
/** S12 命名契约 */
export declare const namingRules: Rule;
/** S13 导出形态契约 */
export declare const exportShape: Rule;
/** S14 有 views 的域必须有 routes.tsx（否则页面访问不到） */
export declare const routesRequired: Rule;
/** S16 体积阈值：文件与组件函数 */
export declare const sizeLimits: Rule;
export declare const structureRules: Rule[];
