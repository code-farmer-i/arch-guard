import type { Rule } from '../../../engine/types.js';
/** H01 类型逃生舱 */
export declare const noTypeEscape: Rule;
/** H02 suppression 注释：门禁不接受内联豁免（豁免只有 config 白名单与基线两条官方通道） */
export declare const noSuppression: Rule;
/** H03 调试残留 */
export declare const noDebugLeftovers: Rule;
/** H04 未完成标记：agent 最爱的退路 */
export declare const noUnfinishedMarkers: Rule;
/** H05 吞异常：空 catch 且无注释说明 */
export declare const noSwallowedError: Rule;
export declare const hygieneRules: Rule[];
