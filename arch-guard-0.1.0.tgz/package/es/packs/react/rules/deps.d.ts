import type { Rule } from '../../../engine/types.js';
/**
 * 依赖域（P）：管两件事
 *   1. 依赖清单纪律 —— 装了什么（P01 白名单 / P02 禁用 / P03 幽灵依赖）
 *   2. 能力纪律 —— 代码里干了什么活、有没有用登记的方案（P06 / P08）
 *
 * 判定等级：清单类 L1（读 package.json），能力类 L2（单文件形态 + 全项目 import 集合）。
 */
/** P01 新增依赖必须登记：**没登记 = 没批准**（只在项目声明了白名单/能力表时启用） */
export declare const depsAllowlist: Rule;
/**
 * P02 明确禁用库。
 * 注意：启用 allow 白名单（P01）后，这个规则基本是多余的 —— 未登记的依赖已经被拦下。
 * 保留它只为两种情况：① 项目不想维护白名单，只想表达少数硬禁令；② 想给某个库更明确的报错。
 */
export declare const depsDenied: Rule;
/** P03 幽灵依赖：import 了却没在任何 dependencies 段声明 */
export declare const phantomDeps: Rule;
/**
 * P06 能力必须用登记方案：命中「手工轮子」强指纹时，必须已经在用该能力的首选方案。
 * 平台内置类能力（structuredClone / Intl / crypto.randomUUID / URLSearchParams）只要命中就报。
 * `allowOwn: true` 的能力降级为 warn（有些小工具自研合理）。
 */
export declare const capabilityPreferred: Rule;
/** P08 登记库必须真的被用：能力首选方案已声明却零引用（死依赖） */
export declare const capabilityUnused: Rule;
export declare const depsRules: Rule[];
